export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { account_id, token, preset, level, since, until } = req.body;

  // Use env token if no user token provided
  const accessToken = token || process.env.META_TOKEN;
  if (!accessToken || !account_id) {
    return res.status(400).json({ error: 'account_id and token required' });
  }

  const fields = [
    level === 'ad' ? 'ad_id,ad_name' : level === 'adset' ? 'adset_id,adset_name,campaign_name' : 'campaign_id,campaign_name',
    'spend,impressions,reach,clicks,ctr,cpc,cpm',
    'actions,action_values,purchase_roas',
    'video_play_actions,video_p25_watched_actions,video_p75_watched_actions',
    'date_start,date_stop'
  ].join(',');

  let url = `https://graph.facebook.com/v19.0/act_${account_id}/insights?fields=${encodeURIComponent(fields)}&level=${level || 'campaign'}&access_token=${accessToken}`;

  if (preset === 'lifetime') {
    url += '&date_preset=lifetime';
  } else if (preset === 'custom' && since && until) {
    url += `&time_range=${encodeURIComponent(JSON.stringify({ since, until }))}&time_increment=1`;
  } else {
    url += `&date_preset=${preset || 'last_30d'}&time_increment=1`;
  }

  try {
    // Fetch all pages
    let rows = [];
    let nextUrl = url;
    let pages = 0;

    while (nextUrl && pages < 15) {
      const response = await fetch(nextUrl);
      const data = await response.json();

      if (data.error) {
        const errCode = data.error.code;
        let msg = data.error.message;
        if (errCode === 190) msg = 'Token منتهي — اعمل جديد من Graph Explorer';
        else if (errCode === 200) msg = 'صلاحيات ناقصة — اضف ads_read';
        return res.status(400).json({ error: msg });
      }

      rows = rows.concat(data.data || []);
      nextUrl = data.paging?.next || null;
      pages++;
    }

    // Aggregate
    const nameKey = level === 'ad' ? 'ad_name' : level === 'adset' ? 'adset_name' : 'campaign_name';
    const getAV = (actions, type) => {
      if (!Array.isArray(actions)) return 0;
      const a = actions.find(x => x.action_type === type || x.action_type?.includes(type));
      return a ? parseFloat(a.value) : 0;
    };

    const totals = { spend: 0, imp: 0, clicks: 0, pur: 0, rev: 0, atc: 0, co: 0, lp: 0 };
    const byEntity = {};

    rows.forEach(r => {
      const name = r[nameKey] || r.campaign_name || r.adset_name || r.ad_name || 'Unknown';
      const spend = parseFloat(r.spend || 0);
      const pur = getAV(r.actions, 'purchase');
      const rev = getAV(r.action_values, 'purchase');
      const atc = getAV(r.actions, 'add_to_cart');
      const co = getAV(r.actions, 'initiate_checkout');
      const lp = getAV(r.actions, 'landing_page_view');
      const plays = getAV(r.video_play_actions);
      const p25 = getAV(r.video_p25_watched_actions);

      totals.spend += spend; totals.imp += parseInt(r.impressions || 0);
      totals.clicks += parseInt(r.clicks || 0); totals.pur += pur;
      totals.rev += rev; totals.atc += atc; totals.co += co; totals.lp += lp;

      if (!byEntity[name]) byEntity[name] = { name, spend: 0, imp: 0, clicks: 0, pur: 0, rev: 0, atc: 0, co: 0, lp: 0, hook: 0, reach: 0 };
      byEntity[name].spend += spend; byEntity[name].imp += parseInt(r.impressions || 0);
      byEntity[name].clicks += parseInt(r.clicks || 0); byEntity[name].pur += pur;
      byEntity[name].rev += rev; byEntity[name].atc += atc; byEntity[name].co += co;
      byEntity[name].lp += lp; byEntity[name].reach += parseInt(r.reach || 0);
      if (plays > 0) byEntity[name].hook = +((p25 / plays) * 100).toFixed(1);
    });

    const roas = totals.spend > 0 ? +(totals.rev / totals.spend).toFixed(2) : 0;
    const cpa = totals.pur > 0 ? +(totals.spend / totals.pur).toFixed(2) : null;
    const ctr = totals.imp > 0 ? +(totals.clicks / totals.imp * 100).toFixed(2) : 0;
    const cvr = totals.lp > 0 ? +(totals.pur / totals.lp * 100).toFixed(2) : 0;

    res.json({
      rows: rows.length,
      pages,
      totals: { ...totals, roas, cpa, ctr, cvr },
      entities: Object.values(byEntity).sort((a, b) => b.spend - a.spend),
      weekly: buildWeekly(rows)
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}

function buildWeekly(rows) {
  const byWeek = {};
  rows.forEach(r => {
    const d = new Date(r.date_start);
    const wn = getWeekNum(d);
    const key = `W${wn}`;
    if (!byWeek[key]) byWeek[key] = { w: key, d: r.date_start, spend: 0, clicks: 0, lp: 0, atc: 0, co: 0, pur: 0, rev: 0 };
    byWeek[key].spend += parseFloat(r.spend || 0);
    byWeek[key].clicks += parseInt(r.clicks || 0);
  });
  return Object.values(byWeek).sort((a, b) => a.w.localeCompare(b.w));
}

function getWeekNum(d) {
  const dt = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  dt.setUTCDate(dt.getUTCDate() + 4 - (dt.getUTCDay() || 7));
  const y = new Date(Date.UTC(dt.getUTCFullYear(), 0, 1));
  return Math.ceil((((dt - y) / 86400000) + 1) / 7);
}
